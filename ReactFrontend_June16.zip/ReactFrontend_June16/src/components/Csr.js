import React from 'react';
import Header from '../Header';
import Footer from '../Footer';
const Csr = () => {
    return(
        <>
            <Header/>
            <Footer/>
        </>
    )
}
export default Csr;