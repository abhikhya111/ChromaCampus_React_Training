import React from 'react';
import Header from '../Header';
import Footer from '../Footer';
const Geographical = () => {
    return (
        <>
            <Header />
            <Footer />
        </>
    )
}
export default Geographical;