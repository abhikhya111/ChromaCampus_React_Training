import './App.css';
import ProductDetails from './components/ProductDetails';
import Header from './Header';
import Footer from './Footer';
import React from 'react';
import { BrowserRouter as Router, Route, Routes} from 'react-router-dom';
import SubCategory from './components/SubCategory';
import { useState, useEffect } from 'react';
import axios from 'axios';

export default function App() {
  const [data, setData] = useState([]);
    const getData = async () => {
      const { data } = await axios.get(`http://localhost:8000/api/getCategories`);
      setData(data);
    };
    function sendCategory(id){
      alert(id);
    }
    useEffect(() => {
      getData();
    }, []);


  

    return (<>
      <div className='app'>
              {/* <ProductDetails/> */}
        {/* <Footer/>  */}
        <Router>
          <Routes>
          {/* <Route path="/products" element={<ProductDetails/>}/> */}
          <Route path="/homepage" element={<ProductDetails/>}/>
          </Routes>
        </Router>
      </div>
      </>
    );
  }
  


