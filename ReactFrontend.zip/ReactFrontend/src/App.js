import './App.css';
import Header from './Header';
import Footer from './Footer';
import React from 'react';
import { BrowserRouter as Router, Route, Routes} from 'react-router-dom';
import { useState, useEffect } from 'react';
import axios from 'axios';
import Home from './components/Home';
import News from './components/News';
import CSR from './components/CSR';
import AboutUs from './components/AboutUs';
import Products from './components/Products';
import Career from './components/Career';
import ContactUs from './components/ContactUs';
import Gallery from './components/Gallery';

export default function App() {
  const [data, setData] = useState([]);
    const getData = async () => {
      const { data } = await axios.get(`http://localhost:8000/api/getCategories`);
      setData(data);
    };
    function sendCategory(id){
      alert(id);
    }
    useEffect(() => {
      getData();
    }, []);


  

    return (<>
      <div className='app'>
              {/* <ProductDetails/> */}
        {/* <Footer/>  */}
        <Router>
          <Routes>
          {/* <Route path="/products" element={<ProductDetails/>}/> */}
          <Route path="/home" element={<Home/>}></Route>
          <Route path="/productDetails" element={<Products/>}/>
          <Route path="/news" element={<News/>}/>
          <Route path="/CSR" element={<CSR/>}/>
          <Route path="/aboutUs" element={<AboutUs/>}/>
          <Route path="/career" element={<Career/>}/>
          <Route path="/contactUs" element={<ContactUs/>}/>
          <Route path="/gallery" element={<Gallery/>}/>

          </Routes>
        </Router>
      </div>
      </>
    );
  }
  


