import React from 'react';
import './Header.css';
import { Navbar,Nav,Container } from 'react-bootstrap';
import { BrowserRouter as Router, Routes,Route } from 'react-router-dom';
import logoHeader from './header-logo.png';
import Home from './components/Home';

export default function Footer() {
  return (
    <div className='header-body'>
         
        <Navbar className="text-dark bg-light">
            <Container>
            <Navbar.Brand href="#home"><img height="60px" src={logoHeader}/></Navbar.Brand>
            <Nav className="me-auto">
            <Nav.Link href="/home" className='Nav_link'>Home</Nav.Link>
            <Nav.Link href="/productDetails" className='Nav_link'>Products</Nav.Link>
            <Nav.Link href="/news" className='Nav_link'>News and Blogs</Nav.Link>
            <Nav.Link href="/CSR" className='Nav_link'>CSR</Nav.Link>
            <Nav.Link href="/" className='Nav_link'>Geographical Presence</Nav.Link>
            <Nav.Link href="/career" className='Nav_link'>Career</Nav.Link>
            <Nav.Link href="/gallery" className='Nav_link'>Gallery</Nav.Link>
            <Nav.Link href="/contactUs" className='Nav_link'>Contact Us</Nav.Link>
            <Nav.Link href="/aboutUs" className='Nav_link'>About Us</Nav.Link>

            </Nav>
            </Container>
        </Navbar>
           
    </div>
  )
}

