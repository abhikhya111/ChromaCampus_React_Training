import React from 'react';
import './Header.css';
import { Navbar,Nav,Container } from 'react-bootstrap';
import logoHeader from './header-logo.png';
export default function Footer() {
  return (
    <div className='header-body'>
        <Navbar className="text-dark bg-light">
            <Container>
            <Navbar.Brand href="#home"><img height="60px" src={logoHeader}/></Navbar.Brand>
            <Nav className="me-auto">
            <Nav.Link href="#home" className='Nav_link'>Home</Nav.Link>
            <Nav.Link href="#features" className='Nav_link'>Products</Nav.Link>
            <Nav.Link href="#pricing" className='Nav_link'>News and Blogs</Nav.Link>
            <Nav.Link href="#pricing" className='Nav_link'>CSR</Nav.Link>
            <Nav.Link href="#pricing" className='Nav_link'>Geographical Presence</Nav.Link>
            <Nav.Link href="#pricing" className='Nav_link'>Career</Nav.Link>
            <Nav.Link href="#pricing" className='Nav_link'>Gallery</Nav.Link>
            <Nav.Link href="#pricing" className='Nav_link'>Contact Us</Nav.Link>
            <Nav.Link href="#pricing" className='Nav_link'>About Us</Nav.Link>

            </Nav>
            </Container>
        </Navbar>
           
    </div>
  )
}

