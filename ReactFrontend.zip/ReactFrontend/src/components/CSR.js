import React from 'react'
import Header from '../Header';
import Footer from '../Footer';

export default function CSR() {
  return (
    <div>
        <Header/>
        <h1>CSR</h1>
        <Footer/>
    </div>
  )
}
