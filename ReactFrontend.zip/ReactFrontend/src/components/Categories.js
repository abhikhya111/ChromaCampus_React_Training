import React from 'react';
import './Category.css';
import axios from 'axios';
import SearchIcon from '@mui/icons-material/Search';
import { useState, useEffect } from 'react';
import { Card, Button } from 'react-bootstrap';
import CategoryCard from './CategoryCard';
import Header from '../Header';
import Footer from '../Footer';

export default function Categories() {
    const [data, setData] = useState([]);
    const getData = async () => {
      const { data } = await axios.get(`http://localhost:8000/api/getCategories`);
      console.log(data);
      setData(data);
    };
    const [data2, setSubCategory] = useState([]);

    const getSubCategory = async (id) => {
      const { data2 } = await axios.get(`http://localhost:8000/api/getSubCategories/${id}`);
      console.log(data2);
      setSubCategory(data2);
    };
    function sendCategory(id){
      alert(id);
    }
    useEffect(() => {
      getData();
      
    }, []);
    return (<div>
      <Header/>
      <h1>h1</h1>
        <div className="sidebarSearch">
                <div className="sidebarSearchContainer">
                    <SearchIcon className='search-icon'/>
                    <input type="text" className="search-input" placeholder="Search product"/>
                </div>
        </div>
        
    
        <ul className='categoryList'>
        {data.map(item => (
            
             <li>
                 
                    <ul className='categoryList'>
                            <li>{item.name}</li>
                          
                        </ul>
                   
            </li>
           ))}
         </ul> 

        <div className="flex-container">
            {data.map(item => (
                <div className='product-details'>
            <a href="/about">
            <img width="300px" onClick={() => getSubCategory(item.id)} src={item.image} /></a>
                <p>{item.name}</p>
                </div>
            ))}
   
        </div>
        <Footer/>
         
</div>)
  }