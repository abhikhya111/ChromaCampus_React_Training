import React from 'react'
import Header from '../Header';
import Footer from '../Footer';

export default function Gallery() {
  return (
    <div>
        <Header/>
        <h1>Gallery</h1>
        <Footer/>
    </div>
  )
}
