import React from 'react'
import Header from '../Header';
import Footer from '../Footer';

export default function News() {
  return (
    <div>
        <Header/>
        <h1> News and Blogs</h1>
        <Footer/>
    </div>
  )
}
