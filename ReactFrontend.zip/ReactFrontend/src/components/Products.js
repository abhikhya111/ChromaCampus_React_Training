import React from 'react'
import Header from '../Header';
import Footer from '../Footer';

export default function Products() {
  return (
    <div>
        <Header/>
        <h1>Product Details</h1>
        <Footer/>
    </div>
  )
}

