import React from 'react'
import Header from '../Header';
import Footer from '../Footer';
import Banner from './careerBanner.png'
import './Career.css';
import {Card} from 'react-bootstrap';
import MarketingImg from './Marketing.png';



export default function Career() {
  return ( <>
    <div>
        <Header/>
        <div>
            <img className='career-banner' src={Banner}/>
        </div>
        <div className='join-content'>
            <h3 className='join-heading'>Join Us</h3>
            <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cursus nibh mauris, nec turpis orci lectus maecenas.
            Suspendisse sed magna eget nibh in turpis. Consequat duis diam lacus arcu. Faucibus venenatis felis id augue
            sit cursus pellentesque enim Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cursus nibh mauris, 
            nec turpis orci lectus maecenas. Suspendisse sed magna eget nibh in turpis. Consequat duis diam lacus arcu. 
            Faucibus venenatis felis id augue sit cursus pellentesque enim Lorem ipsum dolor sit amet, consectetur adipiscing 
            elit. Cursus nibh mauris, nec turpis orci lectus maecenas. Suspendisse sed magna eget nibh in turpis. Consequat
            duis diam lacus arcu. Faucibus venenatis felis id augue sit cursus pellentesque enim 
            </p>
            
            <div className='opening'>
                Current Opening
            </div>
                <div className='cards'>
                    <Card style={{ width: '24rem',  boxShadow: '0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)'}}>
                    <img className="career-img" width="105px" src={MarketingImg} />
                    <Card.Body>
                        <Card.Title><p className='card-title'>Marketing</p> </Card.Title>
                        <Card.Text>
                        Lorem ipsum dolor amet, consectetur adipiscing 
                        elit. Cursus nibh mauris, nec turpis orci lectus 
                        Suspendisse sed magna eget nibh in turpis. 
                        duis diam lacus arcu. Faucibus venenatis felis      
                        </Card.Text>
                    </Card.Body>
                    </Card>

                    <Card style={{ width: '24rem',  boxShadow: '0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)'}}>
                    <img className="career-img" width="105px" src={MarketingImg} />
                    <Card.Body>
                        <Card.Title><p className='card-title'>Marketing</p></Card.Title>
                        <Card.Text>
                        Lorem ipsum dolor amet, consectetur adipiscing 
                        elit. Cursus nibh mauris, nec turpis orci lectus 
                        Suspendisse sed magna eget nibh in turpis. 
                        duis diam lacus arcu. Faucibus venenatis felis 
                        </Card.Text>
                    </Card.Body>
                    </Card>

                    <Card style={{ width: '24rem',  boxShadow: '0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)'}}>
                    <img width="105px" className="career-img" src={MarketingImg} />
                    <Card.Body>
                        <Card.Title><p className='card-title'>Marketing</p></Card.Title>
                        <Card.Text>
                        Lorem ipsum dolor amet, consectetur adipiscing 
                        elit. Cursus nibh mauris, nec turpis orci lectus 
                        Suspendisse sed magna eget nibh in turpis. 
                        duis diam lacus arcu. Faucibus venenatis felis 
                        </Card.Text>
                    </Card.Body>
                    </Card>
                </div>

        

        </div>

        <div className='job-process'>
          
        <Card style={{ width: '24rem',  boxShadow: '0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)'}}>
                    <img className="career-img" width="105px" src={MarketingImg} />
                    <Card.Body>
                        <Card.Title><p className='card-title'>Marketing</p></Card.Title>
                        <Card.Text>
                        Lorem ipsum dolor amet, consectetur adipiscing 
                        elit. Cursus nibh mauris, nec turpis orci lectus 
                        Suspendisse sed magna eget nibh in turpis. 
                        duis diam lacus arcu. Faucibus venenatis felis 
                        </Card.Text>
                    </Card.Body>
                    </Card>
          
        </div>
        <Footer/>

    </div>
</>
  )
}
