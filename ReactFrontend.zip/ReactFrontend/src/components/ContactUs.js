import React from 'react'
import Header from '../Header';
import Footer from '../Footer';

export default function ContactUs() {
  return (
    <div>
        <Header/>
        <h1>Contact Us</h1>
        <Footer/>
    </div>
  )
}
