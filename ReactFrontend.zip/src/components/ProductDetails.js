import React from 'react';
import './ProductDetails.css';
import SearchIcon from '@mui/icons-material/Search';
import Header from '../Header';
import Footer from '../Footer';

export default function App() {
    return (<div>
        <Header />
        <div className="sidebarSearch">
            <div className="sidebarSearchContainer">
                <SearchIcon className='search-icon' />
                <input type="text" className="search-input" placeholder="Search product" />
            </div>
        </div>



        <Footer />

    </div>)
}