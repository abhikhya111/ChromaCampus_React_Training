import React from 'react'
import Header from '../Header';
import Footer from '../Footer';
import { Row, Col, Container, } from 'react-bootstrap';
import './AboutUs.css';
export default function AboutUs() {
    return (
        <div >
            <Header />
            <div className='footer-body'>
                <h3>About Us</h3>
                Home/AboutUs

            </div>

            <Container>
                <Row className='pt-5 pb-5'>

                    <Col md={6} >
                        <h2 className='fontSize2'><u style={{ color: 'red' }}>XTRA POWER TOOL</u></h2>
                        <p className='pt-3 text-dark fontSize'>XTRA POWER is the top-ranking provider of high-quality
                            and innovatively exceptional Power tools, Abrasives, Diamond Saw Blades, TCT, Drill bits,
                            and a wide range of other technically advanced tools to clients from diverse industries and
                            backgrounds. The company has been at the forefront of delivering top-tier tools that vaunt of
                            high-quality and standards. Our products are duly tested for reliability, durability, and
                            performance, which further enable us to offer the best shopping experience to clients including
                            leading businesses and factories.
                        </p>
                    </Col>
                    <Col md={1}></Col>
                    <Col md={5}>
                        <div className='about '>
                            {/* <h1>fhjdhfk</h1> */}
                        </div>
                    </Col>

                </Row>
                {/* <Row >
          
        </Row> */}

            </Container>
            <Row className='colorDiv p-3'>
                <h1>HISTORY</h1>
                <div className='fontSize2'>
                    <Container>
                        <p className='p-3'>The company launched its first set of products in 2002 under the brand name XTRA POWER. With the
                            inauguration of this brand name, the company witnessed an efflux in demand for their tools and
                            accessories, following which they launched a gamut of other products every year. Over the years
                            the company focused on transforming businesses through the adoption of best management practices
                            and by providing sophisticated and refined products as well as unmatched services to their precious
                            clients.Since its establishment, the company has witnessed massive growth & development in the
                            market and is dedicated to meeting and exceeding client expectations through its products and
                            services.
                        </p>
                    </Container>
                </div>
            </Row>
            <Row className='divCenter p-3'>
                <h1 className='text-danger'><strong>WHY US?</strong></h1>
                <div className='fontSize3'>
                    <Container>
                        <p className='p-3 fontSize2'>The company takes pronounced pride in supplying genuine
                            and best quality products through its extensive network of suppliers.
                            With over 500 distributors across India, the company has emerged
                            as the market leader in supplying world-class power tools, abrasives,
                            accessories, and more all over India. LSL Tools Pvt Ltd. has also
                            introduced several other brands in the market. Our popular brands
                            including HIMAX, AWANT, B&P, FASTCUT & REWOP are preferred by professionals
                            for their specific needs and applications.<br></br><br></br>

                            With years of experience and know-how in the field of
                            designing and developing agricultural tools, machine tools, and
                            accessories, we are committed to providing vendors with a variety
                            of products that further allow them to fulfil the market demands efficiently.
                        </p>
                    </Container>
                </div>

            </Row>
            <div>
                <Row >
                    <Col md={4}>
                        <h3 className='text-danger'>100,000</h3>
                        <h5 className='text-danger'>Happy<br />
                            Customers</h5>
                    </Col>
                    <Col md={4} >
                        <h3 className='text-danger'>500</h3>
                        <h5 className='text-danger'>Total Product</h5>
                    </Col>
                    <Col md={4}>
                        <h3 className='text-danger'>1,000</h3>
                        <h5 className='text-danger'>Vendors and<br />
                            Retailers</h5>
                    </Col>

                </Row>
            </div>
            <Footer />
        </div>
    )
}

