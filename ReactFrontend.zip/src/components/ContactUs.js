import React from 'react'
import Header from '../Header';
import Footer from '../Footer';
import ContactUsBanner from './ContactUsBanner.png';
import ContactUs2 from './ContactUs2.png';
import './ContactUs.css';
import { Container, Row, Col } from 'react-bootstrap';

export default function ContactUs() {
  return (
    <div>
        <Header/>
        <img className="w-100" src={ContactUsBanner}/>
        <p>Get In Touch With Us</p>
        <img className='w-100' src={ContactUs2}/>
        <div className="testing-area">
            <Container>
              <Row>
                <Col>
                  <div className='testing-body'>
                  123
                  </div>
                </Col>
                <Col>
                <div className='testing-body'>
                  123
                  </div>
                </Col>
                 <Col>
                 <div className='testing-body'>
                  123
                  </div>
                </Col>
                 <Col>
                 <div className='testing-body'>
                  123
                  </div>
                </Col>
              </Row>
            </Container>
        </div>

        <Footer/>
    </div>
  )
}
