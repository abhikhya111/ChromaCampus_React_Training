import React from 'react';
import './ProductDetails.css';
import axios from 'axios';
import SearchIcon from '@mui/icons-material/Search';
import { useState, useEffect } from 'react';


export default function SubCategory() {
  const [data, setData] = useState([]);
  const getData = async () => {
    const { data } = await axios.get(`http://localhost:8000/api/getCategories`);
    setData(data);
  };
  useEffect(() => {
    getData();
  }, []);
  return (<div>
    <div className="sidebarSearch">
      <div className="sidebarSearchContainer">
        <SearchIcon className='search-icon' />
        <input type="text" className="search-input" placeholder="Search product" />
      </div>
    </div>


    <ul className='categoryList'>
      {data.map(item => (

        <li>
          <ul className='categoryList'>
            <li>{item.name}</li>

          </ul>

        </li>
      ))}
    </ul>

    <div className="flex-container">
      {data.map(item => (
        <div className='product-details'>
          <a href="/about">
            <img width="300px" src={item.image} /></a>
          <p>{item.name}</p>
        </div>
      ))}

    </div>

  </div>)
}