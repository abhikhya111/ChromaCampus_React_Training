import './App.css';
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { useState, useEffect } from 'react';
import axios from 'axios';
import ProductDetails from './components/ProductDetails';
import ProductBase from './components/ProductBase';
import Career from './components/Career';
import AboutUs from './components/AboutUs';
export default function App() {
  // const [data, setData] = useState([]);
  // const getData = async () => {
  //   const { data } = await axios.get(`http://localhost:8000/api/getCategories`);
  //   setData(data);
  // };
  // useEffect(() => {
  //   getData();
  // }, []);
  return (<>
    <div className='app'>
      <Router>
        <Routes>
          <Route path="/homepage" element={<ProductDetails />} />
          <Route path='/productBase' element={<ProductBase />} />
          <Route path='/career' element={<Career />} />
          <Route path='/about-us' element={<AboutUs />} />
        </Routes>
      </Router>
    </div>
  </>
  );
}



